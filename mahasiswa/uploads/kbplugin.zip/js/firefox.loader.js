(async () => {
  const src = chrome.runtime.getURL("/js/service_worker.js");
  await import(src);
})();