
(async () => {
  const src = chrome.runtime.getURL("/js/content_scripts/router.js");
  await import(src);
})();